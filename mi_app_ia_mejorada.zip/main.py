# main.py - App con IA básica mejorada (con monitoreo de sistema)
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
import psutil
import platform

# Respuestas básicas (diccionario simple)
respuestas = {
    "hola": "¡Hola! ¿Cómo estás?",
    "como estas": "Bien, gracias por preguntar.",
    "quien eres": "Soy una IA básica creada para Nerio.",
    "ayuda": "Puedes preguntarme cosas simples, 'estado' para ver recursos, o 'salir'.",
    "gracias": "De nada. Estoy para servirte.",
    "estado": "Voy a mostrarte el estado del sistema.",
}

def obtener_estado():
    ram = psutil.virtual_memory()
    cpu = psutil.cpu_percent(interval=0.5)
    return f"📊 Estado del sistema:\nCPU: {cpu}%\nRAM: {ram.percent}% usada ({ram.used//1024//1024}MB / {ram.total//1024//1024}MB)"

def responder(mensaje):
    mensaje = mensaje.lower().strip()
    if mensaje == "salir":
        return "Hasta luego, Nerio."
    if mensaje == "estado":
        return obtener_estado()
    for palabra, respuesta in respuestas.items():
        if palabra in mensaje:
            return respuesta
    return "No entendí. Escribe 'ayuda' para ver opciones."

class ChatApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical', spacing=10, padding=10)
        self.historial = Label(size_hint_y=0.7, text="", halign='left', valign='top')
        self.historial.bind(size=self.historial.setter('text_size'))
        self.entrada = TextInput(size_hint_y=0.15, multiline=False)
        enviar = Button(text="Enviar", size_hint_y=0.15)
        enviar.bind(on_press=self.enviar_mensaje)
        layout.add_widget(self.historial)
        layout.add_widget(self.entrada)
        layout.add_widget(enviar)
        return layout

    def enviar_mensaje(self, instance):
        texto = self.entrada.text.strip()
        if texto:
            self.historial.text += f"Tú: {texto}\n"
            respuesta = responder(texto)
            self.historial.text += f"IA: {respuesta}\n\n"
            self.entrada.text = ""
            if respuesta == "Hasta luego, Nerio.":
                self.stop()

if __name__ == "__main__":
    ChatApp().run()
